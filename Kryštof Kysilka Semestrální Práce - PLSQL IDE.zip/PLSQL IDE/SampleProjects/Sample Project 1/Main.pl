DECLARE
   a NUMBER := 10.15;
   b NUMBER := 0.05;
   c VARCHAR2(10) := 'print';
   d NUMBER := 1;
   e NUMBER := 2;

BEGIN
   IF NOT d > e THEN
      put_line(d);
   END IF;

   WHILE a < 15.3 
   LOOP
      a := a + b;
      put_line(concat(concat(c, ' '), 'string'));
   END LOOP;
END;
