DECLARE
   a NUMBER := 1;
   b VARCHAR2(30);
   c NUMBER;

BEGIN
   a := 4;
   b := 'abc4$D';
   c := power(power(4, 2), 2);

   BEGIN
      a := 4;
      put_line(a);
   END;

   IF a >= c THEN 
      c := 4 * 10;
      put_line(c);
   ELSIF 4 < power(2, 5) THEN
      put_line(power(2,2));
   ELSE
      c := 4 * 30;
   END IF;
END;
