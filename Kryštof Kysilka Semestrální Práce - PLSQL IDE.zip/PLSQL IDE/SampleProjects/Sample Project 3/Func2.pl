CREATE FUNCTION func2
RETURN NUMBER IS 
   total NUMBER := 0; 
BEGIN 
   total := 5;
   RETURN total;
END;