ACCEPT input NUMBER PROMPT 'Enter number value for Input:';

DECLARE
   a NUMBER := 1;
   c VARCHAR2(100) := '&var1&input';
BEGIN
   a := 4;
   put_line('a : ' ||a);
   a := &numIn;
   put_line('a after input : ' || a);
   put_line(a + &input);
   put_line(c);
   c := func(10, -5, 'funcInput');
   put_line(c);
END;