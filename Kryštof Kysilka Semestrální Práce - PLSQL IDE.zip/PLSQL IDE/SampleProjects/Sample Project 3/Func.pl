CREATE OR REPLACE FUNCTION func (x NUMBER, y NUMBER, z VARCHAR2)
RETURN VARCHAR2 IS 
   total NUMBER := 0; 
   t VARCHAR2(30);
BEGIN 
   total := 5;
   total := y + x;   
   t := 'ret ' || total || z;
   RETURN t; 
END; 