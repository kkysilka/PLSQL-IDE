﻿using System.Collections.Generic;

namespace Logic
{
    public static class Project
    {
        public static string Path { get; set; }
        public static string Name { get; set; }
        public static IList<ProjectFile> FileList { get; set; }
    }
}
