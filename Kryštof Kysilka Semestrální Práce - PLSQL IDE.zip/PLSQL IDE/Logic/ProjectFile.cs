﻿namespace Logic
{
    public class ProjectFile
    {
        public string Name { get; set; }
        public string Text { get; set; }
        public string NameWithExtension { get; set; }
        public string extension = "pl";

        public ProjectFile()
        {
        }

        public ProjectFile(string name, string text)
        {
            Name = name;
            Text = text;
            NameWithExtension = Name + "." + extension;
        }
    }
}
