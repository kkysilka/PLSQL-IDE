﻿using Plsql;
using System;
using System.Collections.Generic;
using System.IO;

namespace Logic
{
    public static class Files
    {
        public delegate void ExceptionEventHandler(object source, ExceptionEventArgs args);
        public static event ExceptionEventHandler ExceptionReceived;

        private static string fileExtension = ".pl";

        public static void ExitIDE()
        {
            Environment.Exit(1);
        }

        public static bool NewProject(string projectPath, string projectName)
        {
            string fullPath = projectPath + "\\" + projectName;

            if (!Directory.Exists(fullPath))
            {
                Directory.CreateDirectory(fullPath);
            }
            else
            {
                return false;
            }

            Project.Path = fullPath;
            Project.Name = projectName;
            Project.FileList = new List<ProjectFile>();

            return true;
        }

        public static bool NewFile(string fileName)
        {
            ProjectFile file = new ProjectFile(fileName, "");

            if (File.Exists(Project.Path + "\\" + file.NameWithExtension))
            {
                return false;
            }

            using (File.CreateText(Project.Path + "\\" + file.NameWithExtension))
            {
            }

            Project.FileList.Add(file);
            return true;
        }

        public static bool OpenProject(string projectPath)
        {
            Project.Path = projectPath;
            DirectoryInfo directoryInfo = new DirectoryInfo(projectPath);
            Project.Name = directoryInfo.Name;

            FileInfo[] files = directoryInfo.GetFiles("*.pl");
            IList<ProjectFile> fileList = new List<ProjectFile>();

            foreach (var item in files)
            {
                string fileText = System.IO.File.ReadAllText(Project.Path + "\\" + item.Name);
                fileList.Add(new ProjectFile(item.Name.Substring(0, item.Name.Length - fileExtension.Length), fileText));
            }

            Project.FileList = fileList;
            return true;
        }

        public static bool SaveFile(string fileName, string fileText)
        {
            foreach (var item in Project.FileList)
            {
                if (item.Name.Equals(fileName))
                {
                    item.Text = fileText;

                    using (StreamWriter writer = new StreamWriter(Project.Path + "\\" + item.NameWithExtension))
                    {
                        writer.Write(item.Text);
                    }
                    return true;
                }
            }
            return false;
        }

        public static bool SaveFileProgress(string fileName, string fileText)
        {
            foreach (var item in Project.FileList)
            {
                if (item.Name.Equals(fileName))
                {
                    item.Text = fileText;
                    return true;
                }
            }

            return false;
        }

        public static bool DeleteFile(string fileName)
        {
            foreach (var item in Project.FileList)
            {
                if (item.Name.Equals(fileName))
                {
                    Project.FileList.Remove(item);
                    File.Delete(Project.Path + "\\" + item.NameWithExtension);
                    return true;
                }
            }
            return false;
        }

        public static bool RenameFile(string oldFileName, string newFileName)
        {
            if (!File.Exists(Project.Path + "\\" + oldFileName + fileExtension) || (File.Exists(Project.Path + "\\" + newFileName + fileExtension)))
            {
                return false;
            }

            foreach (var item in Project.FileList)
            {
                if (item.Name.Equals(oldFileName))
                {
                    File.Move(Project.Path + "\\" + oldFileName + fileExtension, Project.Path + "\\" + newFileName + fileExtension);
                    item.Name = newFileName;
                    return true;
                }
            }
            return false;
        }

        public static bool RenameProject(string newProjectName)
        {
            if (Directory.Exists(Path.GetDirectoryName(Project.Path) + "\\" + newProjectName))
            {
                return false;
            }

            if (Directory.Exists(Project.Path))
            {
                string newProjectPath = Path.GetDirectoryName(Project.Path) + "\\" + newProjectName;
                Directory.Move(Project.Path, newProjectPath);
                Project.Name = newProjectName;
                Project.Path = newProjectPath;
                return true;
            }
            return false;
        }

        public static IList<string> GetProjectFileNames()
        {
            IList<string> listOfNames = new List<string>();

            foreach (var item in Project.FileList)
            {
                listOfNames.Add(item.Name);
            }

            return listOfNames;
        }

        public static string GetFileText(string fileName)
        {
            foreach (var item in Project.FileList)
            {
                if (item.Name.Equals(fileName))
                {
                    return item.Text;
                }
            }

            throw new ArgumentOutOfRangeException("File not found");
        }

        public static void Run(string input, Action<string> outputFunc, Func<string, string> inputFunc)
        {
            InOut.OutputCallback = outputFunc.Invoke;
            InOut.InputCallback = inputFunc.Invoke;

            Parser parser = new Parser();
            Lexer lexer = new Lexer();
            parser.ExceptionThrown += OnExceptionThrown;
            Program program = parser.Parse(lexer.Execute(input));
            if (program == null)
            {
                return;
            }
            program.ExceptionThrown += OnExceptionThrown;
            program.Execute();
        }

        public static void OnExceptionThrown(object source, ExceptionEventArgs e)
        {
            if (e.Position < 0)
            {
                InOut.SetOutput("Exception thrown : " + e.ThrownException.Message);
                OnExceptionReceived(e.ThrownException, -1);
            }
            else
            {
                InOut.SetOutput("Exception thrown : " + e.ThrownException.Message + " on position : " + e.Position);
                OnExceptionReceived(e.ThrownException, e.Position);
            }
        }

        public static void OnExceptionReceived(Exception e, int position)
        {
            if (ExceptionReceived != null)
            {
                ExceptionReceived(null, new ExceptionEventArgs() { ThrownException = e, Position = position });
            }
        }

    }
}
