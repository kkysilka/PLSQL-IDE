﻿
namespace Plsql
{
    public static class InOut
    {

        public delegate void outputCallback(string str);
        public static outputCallback OutputCallback { get; set; }

        public delegate string inputCallback(string str);
        public static inputCallback InputCallback { get; set; }

        public static void SetOutput(string str)
        {
            OutputCallback(str);
        }

        public static string SetInput(string str)
        {
            return InputCallback(str);
        }
    }
}
