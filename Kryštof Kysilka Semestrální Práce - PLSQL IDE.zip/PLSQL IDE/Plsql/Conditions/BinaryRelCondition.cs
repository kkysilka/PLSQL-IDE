﻿namespace Plsql
{
    abstract class BinaryRelCondition : Condition
    {
        protected Expression ExpressionA { get; set; }
        protected Expression ExpressionB { get; set; }
        protected bool Not { get; set; }

        public BinaryRelCondition(Expression expressionA, Expression expressionB, bool not)
        {
            ExpressionA = expressionA;
            ExpressionB = expressionB;
            Not = not;
        }
    }
}
