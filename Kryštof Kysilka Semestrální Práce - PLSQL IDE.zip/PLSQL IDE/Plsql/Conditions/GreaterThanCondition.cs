﻿using System;

namespace Plsql
{
    class GreaterThanCondition : BinaryRelCondition
    {
        public GreaterThanCondition(Expression expressionA, Expression expressionB, bool not) : base(expressionA, expressionB, not)
        {
        }

        public override bool Eval(ExecutionContext ex)
        {
            Value vA = ExpressionA.Eval(ex);
            Value vB = ExpressionB.Eval(ex);

            if (vA is NumberValue && vB is NumberValue)
            {
                bool ret = (vA as NumberValue).Value > (vB as NumberValue).Value;
                if (Not)
                {
                    if (!ret)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                return ret;
            }
            if (vA is StringValue && vB is StringValue)
            {
                if (string.Compare((vA as StringValue).Value, (vA as StringValue).Value) == 1)
                {
                    if (Not)
                    {
                        return false;
                    }
                    return true;
                }
                else
                {
                    if (Not)
                    {
                        return true;
                    }
                    return false;
                }
            }
            throw new InvalidOperationException();
        }
    }
}
