﻿namespace Plsql
{
    abstract class Condition
    {
        public abstract bool Eval(ExecutionContext ex);
    }
}
