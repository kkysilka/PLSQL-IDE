﻿using System;

namespace Plsql
{
    class BinaryExpression : Expression
    {
        private Expression ExpressionA { get; set; }
        private Expression ExpressionB { get; set; }
        private OperatorToken OperatorToken { get; set; }

        public BinaryExpression(Expression expressionA, Expression expressionB, OperatorToken operatorToken) : base(null)
        {
            ExpressionA = expressionA;
            ExpressionB = expressionB;
            OperatorToken = operatorToken;
        }

        public override Value Eval(ExecutionContext ex)
        {
            Value vA = ExpressionA.Eval(ex);
            Value vB = ExpressionB.Eval(ex);

            switch (OperatorToken.OperatorType)
            {
                case OperatorType.Plus:
                    if (vA is NumberValue && vB is NumberValue)
                    {
                        return new NumberValue((vA as NumberValue).Value + (vB as NumberValue).Value);
                    }
                    throw new InvalidOperationException("Invalid operation.");
                case OperatorType.Minus:
                    if (vA is NumberValue && vB is NumberValue)
                    {
                        return new NumberValue((vA as NumberValue).Value - (vB as NumberValue).Value);
                    }
                    throw new InvalidOperationException("Invalid operation.");
                case OperatorType.Times:
                    if (vA is NumberValue && vB is NumberValue)
                    {
                        return new NumberValue((vA as NumberValue).Value * (vB as NumberValue).Value);
                    }
                    throw new InvalidOperationException("Invalid operation.");
                case OperatorType.Devide:
                    if (vA is NumberValue && vB is NumberValue)
                    {
                        return new NumberValue((vA as NumberValue).Value / (vB as NumberValue).Value);
                    }
                    throw new InvalidOperationException("Invalid operation.");
                case OperatorType.Concat:
                    if (vA is StringValue && vB is StringValue)
                    {
                        return new StringValue((vA as StringValue).Value + (vB as StringValue).Value);
                    }
                    if (vA is StringValue && vB is NumberValue)
                    {
                        return new StringValue((vA as StringValue).Value + (vB as NumberValue).Value.ToString());
                    }
                    if (vA is NumberValue && vB is StringValue)
                    {
                        return new StringValue((vA as NumberValue).Value.ToString() + (vB as StringValue).Value);
                    }
                    if (vA is NumberValue && vB is NumberValue)
                    {
                        return new StringValue((vA as NumberValue).Value.ToString() + (vB as NumberValue).Value.ToString());
                    }
                    throw new InvalidOperationException("Invalid operation.");
                default:
                    throw new InvalidOperationException("Invalid operation.");
            }
        }
    }
}
