﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Plsql
{
    class LiteralExpression : Expression
    {
        private bool isNumberInput;
        private string identifier;

        public LiteralExpression(Value value) : base(value)
        {
        }

        public LiteralExpression(Value value, bool isNumberInput, string identifier) : base(value)
        {
            this.isNumberInput = isNumberInput;
            this.identifier = identifier;
        }

        public override Value Eval(ExecutionContext ex)
        {
            if (value is StringValue && ex.inputVariables != null)
            {
                IList<string> matchList = new List<string>();
                IList<int> matchIndexList = new List<int>();
                string str = (value as StringValue).Value;

                Regex rx = new Regex(@"[&][0-9a-zA-z_]+");
                foreach (Match match in rx.Matches(str))
                {
                    int startIndex = match.Index;
                    int endIndex = -1;

                    for (int i = startIndex + 1; i < str.Length; i++)
                    {
                        Match match2 = Regex.Match(str[i].ToString(), @"[^0-9a-zA-z_]");
                        if (match2.Success)
                        {
                            endIndex = i;
                            break;
                        }
                    }
                    if (endIndex == -1)
                    {
                        endIndex = str.Length;
                    }

                    string substr = str.Substring(startIndex, endIndex - startIndex);
                    matchList.Add(substr);
                    matchIndexList.Add(startIndex);
                }

                for (int i = 0; i < matchList.Count; i++)
                {
                    string id = matchList[i].Substring(1, matchList[i].Length - 1);
                    string inputString;

                    if (ex.inputVariables.FindVariable(id))
                    {
                        Value v = ex.inputVariables.GetVariableValue(id);
                        if (v is NumberValue)
                        {
                            inputString = (v as NumberValue).Value.ToString();
                        }
                        else
                        {
                            inputString = (v as StringValue).Value;
                        }
                    }
                    else
                    {
                        InputStatement inputStatement = new InputStatement(id, "Enter value for " + id, KeywordType.Char);
                        inputString = (inputStatement.Execute(ex) as StringValue).Value;
                    }
                    Regex regex = new Regex(Regex.Escape(matchList[i]));
                    str = regex.Replace(str, inputString, 1);
                }

            (value as StringValue).Value = str;
            }
            else
            {
                if (isNumberInput)
                {
                    double inputNumber;
                    identifier = identifier.Substring(1);

                    if (ex.inputVariables.FindVariable(identifier))
                    {
                        Value v = ex.inputVariables.GetVariableValue(identifier);
                        if (v is NumberValue)
                        {
                            inputNumber = (v as NumberValue).Value;
                        }
                        else
                        {
                            throw new VariableHasIncorrectDataTypeException();
                        }
                    }
                    else
                    {
                        InputStatement inputStatement = new InputStatement(identifier, "Enter value for " + identifier, KeywordType.Number);
                        inputNumber = (inputStatement.Execute(ex) as NumberValue).Value;

                    }
                    (value as NumberValue).Value = inputNumber;
                    isNumberInput = false;
                }
            }
            return value;
        }
    }
}
