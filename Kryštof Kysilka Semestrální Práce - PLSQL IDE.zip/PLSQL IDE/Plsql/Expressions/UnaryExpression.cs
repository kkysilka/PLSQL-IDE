﻿using System;

namespace Plsql
{
    class UnaryExpression : Expression
    {

        private Expression expression;
        private OperatorToken operatorToken;

        public UnaryExpression(Expression expression, OperatorToken operatorToken) : base(null)
        {
            this.expression = expression;
            this.operatorToken = operatorToken;
        }

        public override Value Eval(ExecutionContext ex)
        {
            Value v = expression.Eval(ex);
            if (v is NumberValue)
            {
                if (operatorToken.OperatorType == OperatorType.Minus)
                {
                    (v as NumberValue).Value = -(v as NumberValue).Value;
                    return (NumberValue)v;
                }
                else
                {
                    return (NumberValue)v;
                }
            }
            else
            {
                throw new InvalidOperationException();
            }
        }
    }
}
