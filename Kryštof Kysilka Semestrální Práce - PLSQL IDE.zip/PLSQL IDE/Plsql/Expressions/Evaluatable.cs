﻿namespace Plsql
{
    interface Evaluatable
    {
        public Value Eval(ExecutionContext executionContext);
    }
}
