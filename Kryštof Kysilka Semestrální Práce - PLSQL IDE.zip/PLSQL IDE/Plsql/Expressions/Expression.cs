﻿namespace Plsql
{
    abstract class Expression : Evaluatable
    {
        public Value value;

        public Expression(Value value)
        {
            this.value = value;
        }

        public abstract Value Eval(ExecutionContext executionContext);
    }
}
