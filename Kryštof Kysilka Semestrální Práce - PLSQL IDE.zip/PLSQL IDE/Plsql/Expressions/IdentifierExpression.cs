﻿namespace Plsql
{
    class IdentifierExpression : Expression
    {
        private string name;

        public IdentifierExpression(string name) : base(null)
        {
            this.name = name;
        }

        public override Value Eval(ExecutionContext ex)
        {
            Value v;

            while (ex != null)
            {
                try
                {
                    if (ex.variables == null)
                    {
                        ex = ex.upperExecutionContext;
                        continue;
                    }
                    v = ex.variables.GetVariableValue(name);
                    return v;
                }
                catch (VariableDoesNotExistException)
                {
                    ex = ex.upperExecutionContext;
                }
            }
            throw new VariableDoesNotExistException("Variable does not exist in the current context.");
        }
    }
}
