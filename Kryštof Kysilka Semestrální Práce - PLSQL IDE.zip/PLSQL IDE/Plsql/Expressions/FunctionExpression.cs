﻿using System.Collections.Generic;

namespace Plsql
{
    class FunctionExpression : Expression
    {
        private string name;
        private IList<Expression> expressionList;

        public FunctionExpression(string name, IList<Expression> expressionList) : base(null)
        {
            this.name = name;
            this.expressionList = expressionList;
        }

        public override Value Eval(ExecutionContext ex)
        {
            List<Value> valueList = null;
            if (expressionList != null)
            {
                valueList = new List<Value>();

                foreach (var item in expressionList)
                {
                    valueList.Add(item.Eval(ex));
                }
            }

            ExecutionContext executionContext = new ExecutionContext(ex.programContext, null, null, null);
            executionContext.SetParametrs(valueList);

            if (executionContext.programContext.Find(name))
            {
                return executionContext.programContext.Call(name, executionContext);
            }

            throw new FunctionDoesNotExistException("Function does not exist. " + name);
        }
    }
}
