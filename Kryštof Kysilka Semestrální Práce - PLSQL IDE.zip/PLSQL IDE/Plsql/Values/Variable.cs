﻿namespace Plsql
{
    public class Variable
    {
        public string Identifier { get; private set; }
        public bool Constant { get; private set; }

        public Variable(string name, bool constant)
        {
            Identifier = name;
            Constant = constant;
        }
    }
}
