﻿namespace Plsql
{
    class NumberValue : Value
    {
        public double Value { get; set; }

        public NumberValue()
        {
            Returned = false;
        }

        public NumberValue(double value)
        {
            Value = value;
            Returned = false;
        }
    }
}
