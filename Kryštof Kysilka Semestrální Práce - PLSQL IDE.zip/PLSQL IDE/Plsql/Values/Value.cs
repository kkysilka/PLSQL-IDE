﻿namespace Plsql
{
    public class Value
    {
        public bool Returned { get; set; }
    }
}
