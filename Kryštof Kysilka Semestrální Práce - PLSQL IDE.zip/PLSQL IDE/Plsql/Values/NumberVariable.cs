﻿namespace Plsql
{
    class NumberVariable : Variable
    {
        public double Value { get; set; }

        public NumberVariable(string identifier, double value, bool constant) : base(identifier, constant)
        {
            Value = value;
        }
    }
}
