﻿namespace Plsql
{
    class StringVariable : Variable
    {
        public string Value { get; set; }
        public int Size { get; private set; }

        public StringVariable(string identifier, string value, bool constant, int size) : base(identifier, constant)
        {
            Value = value;
            Size = size;
        }
    }
}
