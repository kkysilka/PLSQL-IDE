﻿namespace Plsql
{
    class StringValue : Value
    {
        public string Value { get; set; }

        public StringValue()
        {
            Returned = false;
        }

        public StringValue(string value)
        {
            Value = value;
            Returned = false;
        }
    }
}
