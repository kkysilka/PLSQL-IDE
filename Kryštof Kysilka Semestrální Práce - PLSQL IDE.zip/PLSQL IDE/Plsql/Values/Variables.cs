﻿using System.Collections.Generic;
using System.Diagnostics;

namespace Plsql
{
    public class Variables
    {
        private IList<Variable> variableList;

        public Variables()
        {
            variableList = new List<Variable>();
        }

        public Variables(IList<Variable> variableList)
        {
            this.variableList = new List<Variable>();
            foreach (var item in variableList)
            {
                this.variableList.Add(item);
            }
        }

        public Value GetVariableValue(string name)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == name)
                {
                    if (item is NumberVariable)
                    {
                        return new NumberValue((item as NumberVariable).Value);
                    }
                    else
                    {
                        return new StringValue((item as StringVariable).Value);
                    }
                }
            }
            throw new VariableDoesNotExistException();
        }

        public bool SetVariable(string identifier, double value)
        {
            if (variableList == null)
            {
                return false;
            }

            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    if (item.Constant)
                    {
                        throw new VariableIsConstantException("Variable is constant.");
                    }

                    if (item is NumberVariable)
                    {
                        (item as NumberVariable).Value = value;
                        return true;
                    }

                    throw new VariableHasIncorrectDataTypeException();
                }
            }
            return false;
        }

        public bool SetVariable(string identifier, string value)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    if (item.Constant)
                    {
                        throw new VariableIsConstantException("Variable is constant.");
                    }

                    if (item is StringVariable)
                    {
                        if ((item as StringVariable).Size >= value.Length)
                        {
                            (item as StringVariable).Value = value;
                            return true;
                        }
                        throw new CharacterStringBufferTooSmallException();
                    }
                    throw new VariableHasIncorrectDataTypeException(identifier);
                }
            }
            return false;
        }

        public void AddNumberVariable(string identifier)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    throw new VariableAlreadyExistsException();
                }
            }

            variableList.Add(new NumberVariable(identifier, double.NaN, false));
        }

        public void AddStringVariable(string identifier, int size)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    throw new VariableAlreadyExistsException();
                }
            }

            variableList.Add(new StringVariable(identifier, string.Empty, false, size));
        }

        public void AddConstantNumberVariable(string identifier, double value)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    throw new VariableAlreadyExistsException(identifier);
                }
            }

            variableList.Add(new NumberVariable(identifier, value, true));
        }

        public void AddConstantStringVariable(string identifier, int size, string value)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    throw new VariableAlreadyExistsException(identifier);
                }
            }

            variableList.Add(new StringVariable(identifier, value, true, size));
        }

        public bool SetConstantVariable(string identifier, double value)
        {
            if (variableList == null)
            {
                return false;
            }

            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    if (item is NumberVariable)
                    {
                        (item as NumberVariable).Value = value;
                        return true;
                    }

                    throw new VariableHasIncorrectDataTypeException();
                }
            }
            return false;
        }

        public bool SetConstantVariable(string identifier, string value)
        {
            if (variableList == null)
            {
                return false;
            }

            foreach (var item in variableList)
            {
                if (item.Identifier == identifier)
                {
                    if (item is StringVariable)
                    {
                        (item as StringVariable).Value = value;
                        return true;
                    }

                    throw new VariableHasIncorrectDataTypeException();
                }
            }
            return false;
        }




        public bool FindVariable(string name)
        {
            foreach (var item in variableList)
            {
                if (item.Identifier == name)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
