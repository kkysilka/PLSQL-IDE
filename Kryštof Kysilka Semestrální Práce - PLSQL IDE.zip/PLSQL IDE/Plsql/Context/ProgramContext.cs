﻿using System.Collections.Generic;

namespace Plsql
{
    public class ProgramContext
    {
        private IList<Function> functionList;

        public ProgramContext(IList<Function> functionList)
        {
            this.functionList = functionList;
        }

        public Value Call(string identifier, ExecutionContext executionContext)
        {
            foreach (var item in functionList)
            {
                if (item.Identifier.ToLower() == identifier.ToLower())
                {
                    return item.Execute(executionContext);
                }
            }
            return null;
        }

        public bool Find(string identifier)
        {
            foreach (var item in functionList)
            {
                if (item.Identifier.ToLower() == identifier.ToLower())
                {
                    return true;
                }
            }
            return false;
        }
    }
}
