﻿using System.Collections.Generic;

namespace Plsql
{
    public class ExecutionContext
    {
        public ProgramContext programContext;
        public Variables variables;
        public Variables inputVariables;
        public ExecutionContext upperExecutionContext;
        public IList<Value> parameterList = null;

        public ExecutionContext()
        {
        }

        public ExecutionContext(ProgramContext programContext, Variables variables, Variables inputVariables, ExecutionContext upperExecutionContext)
        {
            this.programContext = programContext;
            this.variables = variables;
            this.inputVariables = inputVariables;
            this.upperExecutionContext = upperExecutionContext;
        }

        public void SetParametrs(IList<Value> parameterList)
        {
            this.parameterList = parameterList;
        }
    }
}
