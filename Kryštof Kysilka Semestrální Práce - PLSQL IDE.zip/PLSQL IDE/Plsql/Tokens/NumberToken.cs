﻿namespace Plsql
{
    class NumberToken : Token
    {
        public double Value { get; set; }

        public NumberToken(TokenType type, int position, double value) : base(type, position)
        {
            Value = value;
        }
    }
}
