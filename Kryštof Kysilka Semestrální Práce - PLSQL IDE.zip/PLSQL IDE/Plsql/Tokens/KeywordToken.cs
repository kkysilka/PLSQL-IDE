﻿namespace Plsql
{
    class KeywordToken : Token
    {
        public KeywordType KeywordType { get; set; }

        public KeywordToken(TokenType type, int position, KeywordType keywordType) : base(type, position)
        {
            KeywordType = keywordType;
        }
    }
}
