﻿namespace Plsql
{
    class StringToken : Token
    {
        public string Value { get; set; }

        public StringToken(TokenType type, int position, string value) : base(type, position)
        {
            Value = value;
        }
    }
}
