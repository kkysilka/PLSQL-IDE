﻿namespace Plsql
{
    class OperatorToken : Token
    {
        public OperatorType OperatorType { get; set; }

        public OperatorToken(TokenType type, int position, OperatorType operatorType) : base(type, position)
        {
            OperatorType = operatorType;
        }
    }
}
