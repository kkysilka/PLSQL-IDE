﻿namespace Plsql
{
    class SeparatorToken : Token
    {
        public SeparatorType SeparatorType { get; set; }

        public SeparatorToken(TokenType type, int position, SeparatorType separatorType) : base(type, position)
        {
            SeparatorType = separatorType;
        }
    }
}
