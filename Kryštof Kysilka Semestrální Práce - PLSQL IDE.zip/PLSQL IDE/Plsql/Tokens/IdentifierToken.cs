﻿namespace Plsql
{
    class IdentifierToken : Token
    {
        public string Name { get; set; }

        public IdentifierToken(TokenType type, int position, string name) : base(type, position)
        {
            Name = name;
        }

    }
}
