﻿namespace Plsql
{
    public class Token
    {
        public TokenType Type { get; set; }
        public int Position { get; set; }

        public Token(TokenType type, int position)
        {
            Type = type;
            Position = position;
        }
    }

    public enum TokenType
    {
        Identifier,
        KeyWord,
        Operator,
        Separator,
        Value
    }
}
