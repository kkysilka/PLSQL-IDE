﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    public class Lexer
    {
        private int startPosition;
        private bool reading;
        private bool readingString;
        private string token;
        private IList<Token> tokenList;

        public IList<Token> Execute(string input)
        {
            reading = false;
            readingString = false;
            startPosition = -1;
            token = "";
            tokenList = new List<Token>();

            try
            {
                for (int pointer = 0; pointer < input.Length; pointer++)
                {
                    if (readingString)
                    {
                        if (input[pointer] == '\'')
                        {
                            readingString = false;
                        }
                        else
                        {
                            continue;
                        }
                    }

                    if (char.IsWhiteSpace(input[pointer]))
                    {
                        if (reading)
                        {
                            token = input.Substring(startPosition, pointer - startPosition);
                            reading = false;
                            tokenList.Add(Dictionary.GetToken(token, startPosition));
                        }
                        continue;
                    }

                    if (Dictionary.IsOperator(input[pointer].ToString()) || Dictionary.IsSeparator(input[pointer]))
                    {
                        if (pointer < input.Length - 2 && input[pointer] == '.' && input[pointer + 1] != '.')
                        {
                            continue;
                        }

                        if (reading)
                        {
                            token = input.Substring(startPosition, pointer - startPosition);
                            reading = false;
                            tokenList.Add(Dictionary.GetToken(token, startPosition));
                        }

                        startPosition = pointer;
                        token = input[pointer].ToString();

                        if (pointer < input.Length - 2)
                        {
                            if (Dictionary.IsOperator(input[pointer].ToString()) && Dictionary.IsOperator(input[pointer + 1].ToString()))
                            {
                                token = input.Substring(startPosition, pointer + 2 - startPosition);
                                if (Dictionary.IsOperator(token))
                                {
                                    tokenList.Add(Dictionary.GetToken(token, startPosition));
                                    pointer++;
                                    continue;
                                }
                                else
                                {
                                    throw new InvalidOperationException("Invalid operator.");
                                }
                            }
                        }
                        tokenList.Add(Dictionary.GetToken(token, startPosition));
                        continue;
                    }

                    if (!reading)
                    {
                        reading = true;
                        startPosition = pointer;
                        if (input[pointer] == '\'')
                        {
                            readingString = true;
                        }
                    }
                }

            }
            catch (Exception e)
            {
                InOut.SetOutput("Exception thrown : " + e.Message);
            }

            return tokenList;
        }
    }
}