﻿using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Plsql
{
    static class Dictionary
    {
        private static IList<string> keywordList = new List<string> { "declare", "constant", "begin", "end", "while", "for", "if" ,
            "then", "elsif", "else", "loop", "in", "not", "and", "or", "number", "varchar2", "create", "function", "is", "accept",
            "char", "prompt", "replace", "return"};
        private static IList<string> separatorList = new List<string> { ",", ";", "(", ")" };
        private static IList<string> operatorList = new List<string> { "+", "-", "*", "/", ":=", "=", "!=", "<>", "<", ">", "<=", ">=", "..", "||", ":", "!", "|", "." };
        private static string FromTo = "..";

        public static Token GetToken(string input, int position)
        {
            Token token = null;
            string inputLower = input.ToLower();

            if (keywordList.Contains(inputLower))
            {
                int index = keywordList.IndexOf(inputLower);

                switch (index)
                {
                    case 0:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Declare);
                        break;
                    case 1:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Constant);
                        break;
                    case 2:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Begin);
                        break;
                    case 3:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.End);
                        break;
                    case 4:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.While);
                        break;
                    case 5:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.For);
                        break;
                    case 6:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.If);
                        break;
                    case 7:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Then);
                        break;
                    case 8:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Elsif);
                        break;
                    case 9:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Else);
                        break;
                    case 10:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Loop);
                        break;
                    case 11:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.In);
                        break;
                    case 12:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Not);
                        break;
                    case 13:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.And);
                        break;
                    case 14:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Or);
                        break;
                    case 15:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Number);
                        break;
                    case 16:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Varchar2);
                        break;
                    case 17:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Create);
                        break;
                    case 18:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Function);
                        break;
                    case 19:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Is);
                        break;
                    case 20:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Accept);
                        break;
                    case 21:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Char);
                        break;
                    case 22:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Prompt);
                        break;
                    case 23:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Replace);
                        break;
                    case 24:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Return);
                        break;
                    case 25:
                        token = new KeywordToken(TokenType.KeyWord, position, KeywordType.Print);
                        break;
                }

                return token;
            }

            if (operatorList.Contains(inputLower))
            {
                int index = operatorList.IndexOf(inputLower);

                switch (index)
                {
                    case 0:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Plus);
                        break;
                    case 1:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Minus);
                        break;
                    case 2:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Times);
                        break;
                    case 3:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Devide);
                        break;
                    case 4:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Equals);
                        break;
                    case 5:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.EqualTo);
                        break;
                    case 6:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.NotEqualTo);
                        break;
                    case 7:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.NotEqualTo);
                        break;
                    case 8:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.LessThan);
                        break;
                    case 9:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.GreaterThan);
                        break;
                    case 10:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.LessThanOrEqualTo);
                        break;
                    case 11:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.GreaterThanOrEqualTo);
                        break;
                    case 12:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.FromTo);
                        break;
                    case 13:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Concat);
                        break;
                    case 14:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Colon);
                        break;
                    case 15:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.ExclamationMark);
                        break;
                    case 16:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.VerticalBar);
                        break;
                    case 17:
                        token = new OperatorToken(TokenType.Operator, position, OperatorType.Dot);
                        break;
                }
                return token;
            }

            if (separatorList.Contains(inputLower))
            {
                int index = separatorList.IndexOf(inputLower);

                switch (index)
                {
                    case 0:
                        token = new SeparatorToken(TokenType.Separator, position, SeparatorType.Comma);
                        break;
                    case 1:
                        token = new SeparatorToken(TokenType.Separator, position, SeparatorType.Semicolon);
                        break;
                    case 2:
                        token = new SeparatorToken(TokenType.Separator, position, SeparatorType.LeftBracket);
                        break;
                    case 3:
                        token = new SeparatorToken(TokenType.Separator, position, SeparatorType.RightBracket);
                        break;
                }
                return token;
            }

            if (input.StartsWith("\'") && input.EndsWith("\'"))
            {
                input = input.Substring(1, input.Length - 2);
                token = new StringToken(TokenType.Value, position, input);
                return token;
            }

            bool isNumber = double.TryParse(input, System.Globalization.NumberStyles.Any, CultureInfo.InvariantCulture, out double n);
            if (isNumber)
            {
                token = new NumberToken(TokenType.Value, position, n);
                return token;
            }

            bool match = false;
            match = Regex.IsMatch(input, @"[&a-zA-Z0-9_]+$");
            if (!match)
            {
                throw new VariableHasIncorrectNameException();
            }
            token = new IdentifierToken(TokenType.Identifier, position, input);
            return token;
        }


        public static bool IsOperator(string input)
        {
            if (operatorList.Contains(input.ToString()))
            {
                return true;
            }
            return false;
        }

        public static bool IsSeparator(char input)
        {
            if (separatorList.Contains(input.ToString()))
            {
                return true;
            }
            return false;
        }

        public static bool IsFromTo(char i1, char i2)
        {
            if (FromTo.Equals(i1.ToString() + i2.ToString()))
            {
                return true;
            }
            return false;
        }

    }

    public enum KeywordType
    {
        Declare,
        Constant,
        Begin,
        End,
        While,
        For,
        If,
        Then,
        Elsif,
        Else,
        Loop,
        In,
        Not,
        And,
        Or,
        Number,
        Varchar2,
        Create,
        Function,
        Is,
        Accept,
        Char,
        Prompt,
        Replace,
        Return,
        Print
    }

    public enum SeparatorType
    {
        Semicolon,
        Comma,
        LeftBracket,
        RightBracket
    }

    public enum OperatorType
    {
        Plus,
        Minus,
        Times,
        Devide,
        Equals,
        EqualTo,
        NotEqualTo,
        LessThan,
        GreaterThan,
        LessThanOrEqualTo,
        GreaterThanOrEqualTo,
        FromTo,
        Concat,
        Colon,
        ExclamationMark,
        VerticalBar,
        Dot
    }
}
