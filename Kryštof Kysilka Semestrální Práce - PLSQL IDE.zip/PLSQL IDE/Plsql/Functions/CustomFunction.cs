﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    class CustomFunction : Function
    {
        private IList<SetStatement> variableSetList;
        private IList<Variable> variableList;
        private IList<Variable> parameterList;
        private Statement statement;
        private Value returnValue;
        private KeywordType returnType;

        public CustomFunction(string identifier, IList<SetStatement> variableSetList, IList<Variable> variableList,
            Statement statement, IList<Variable> parameterList, KeywordType returnType) : base(identifier)
        {
            this.variableSetList = variableSetList;
            this.variableList = variableList;
            this.statement = statement;
            this.returnType = returnType;
            this.parameterList = parameterList;
        }

        public override Value Execute(ExecutionContext ex)
        {
            CustomFunction function = new CustomFunction(Identifier, variableSetList, variableList, statement, parameterList, returnType);
            return function.ExecuteNewInstance(ex);
        }

        private Value ExecuteNewInstance(ExecutionContext ex)
        {
            Variables variables;

            if (variableList == null && variableSetList == null)
            {
                variables = new Variables();
            }
            else
            {
                variables = new Variables(variableList);
            }

            ExecutionContext executionContext = new ExecutionContext(ex.programContext, variables, null, ex);

            if (ex.parameterList != null && parameterList.Count == ex.parameterList.Count)
            {
                for (int i = 0; i < parameterList.Count; i++)
                {
                    if (parameterList[i] is NumberVariable && ex.parameterList[i] is NumberValue)
                    {
                        variables.AddConstantNumberVariable(parameterList[i].Identifier, (ex.parameterList[i] as NumberValue).Value);
                    }
                    else if (parameterList[i] is StringVariable && ex.parameterList[i] is StringValue)
                    {
                        variables.AddConstantStringVariable(parameterList[i].Identifier, int.MaxValue, (ex.parameterList[i] as StringValue).Value);
                    }
                    else
                    {
                        throw new InvalidOperationException();
                    }
                }
            }

            if (variableList != null && variableSetList != null)
            {
                foreach (var item in variableSetList)
                {
                    item.Execute(executionContext);
                }
            }

            returnValue = statement.Execute(executionContext);
            if (returnValue == null)
            {
                throw new FunctionHasToReturnValueException();
            }
            if ((returnValue is NumberValue && returnType != KeywordType.Number) || (returnValue is StringValue && returnType != KeywordType.Varchar2) ||
                ((!(returnValue is NumberValue)) && (!(returnValue is StringValue))))
            {
                throw new FunctionHasToReturnCorrectDataTypeException();
            }

            returnValue.Returned = false;

            return returnValue;
        }
    }
}
