﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    class FloorFunction : Function
    {
        private IList<Value> parameterList;

        public FloorFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new NumberValue());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (!TestParams(parameterList, ex.parameterList))
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            NumberValue v = ex.parameterList[0] as NumberValue;
            v.Value = Math.Floor(v.Value);
            return v;
        }
    }
}
