﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    class PowerFunction : Function
    {
        private IList<Value> parameterList;

        public PowerFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new NumberValue());
            parameterList.Add(new NumberValue());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (!TestParams(parameterList, ex.parameterList))
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            NumberValue v1 = ex.parameterList[0] as NumberValue;
            NumberValue v2 = ex.parameterList[1] as NumberValue;
            return new NumberValue(Math.Pow(v1.Value, v2.Value));
        }
    }
}
