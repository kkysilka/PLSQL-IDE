﻿using System.Collections.Generic;

namespace Plsql
{
    class ToCharFunction : Function
    {
        private IList<Value> parameterList;

        public ToCharFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new NumberValue());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (!TestParams(parameterList, ex.parameterList))
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            NumberValue v = ex.parameterList[0] as NumberValue;
            return new StringValue(v.Value.ToString());
        }
    }
}
