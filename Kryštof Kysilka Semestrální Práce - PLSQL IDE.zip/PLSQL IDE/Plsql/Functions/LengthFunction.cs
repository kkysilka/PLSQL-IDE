﻿using System.Collections.Generic;

namespace Plsql
{
    class LengthFunction : Function
    {
        private IList<Value> parameterList;

        public LengthFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new StringValue());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (!TestParams(parameterList, ex.parameterList))
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            StringValue v = ex.parameterList[0] as StringValue;
            return new NumberValue(v.Value.Length);
        }
    }
}
