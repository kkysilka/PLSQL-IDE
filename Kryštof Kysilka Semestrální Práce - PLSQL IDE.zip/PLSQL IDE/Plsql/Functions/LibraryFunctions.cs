﻿using System.Collections.Generic;

namespace Plsql
{
    static class LibraryFunctions
    {

        public static IList<Function> GetLibraryFunctions()
        {
            IList<Function> list = new List<Function>
            {
                new PutLineFunction("put_line"),
                new FloorFunction("floor"),
                new ConcatFunction("concat"),
                new LengthFunction("length"),
                new PowerFunction("power"),
                new ToCharFunction("to_char"),
                new ToNumberFunction("to_number")
            };

            return list;
        }

    }
}
