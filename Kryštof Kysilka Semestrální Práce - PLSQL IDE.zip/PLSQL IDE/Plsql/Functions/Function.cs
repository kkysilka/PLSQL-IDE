﻿using System.Collections.Generic;

namespace Plsql
{
    public abstract class Function
    {
        public string Identifier { get; private set; }

        protected Function(string identifier)
        {
            Identifier = identifier;
        }

        public abstract Value Execute(ExecutionContext ex);

        public bool TestParams(IList<Value> inList, IList<Value> outList)
        {
            if (outList != null && outList.Count == inList.Count)
            {
                for (int i = 0; i < inList.Count; i++)
                {
                    if ((inList[i] is NumberValue && outList[i] is NumberValue) || (inList[i] is StringValue && outList[i] is StringValue))
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        public bool TestParams(IList<Variable> inList, IList<Value> outList)
        {
            if (outList != null && outList.Count == inList.Count)
            {
                for (int i = 0; i < inList.Count; i++)
                {
                    if ((inList[i] is NumberVariable && outList[i] is NumberValue) || (inList[i] is StringVariable && outList[i] is StringValue))
                    {
                        continue;
                    }
                    else
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }
    }
}
