﻿using System.Collections.Generic;

namespace Plsql
{
    class PutLineFunction : Function
    {
        private IList<Value> parameterList;

        public PutLineFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new Value());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (ex.parameterList == null || ex.parameterList.Count != 1)
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            Value v = ex.parameterList[0];

            if (v is NumberValue)
            {
                string stringOut;
                double dv = (v as NumberValue).Value;
                if (double.IsNaN(dv))
                {
                    stringOut = "";
                }
                else
                {
                    stringOut = dv.ToString();
                }
                InOut.SetOutput(stringOut);
            }
            else
            {
                string stringOut = (v as StringValue).Value;
                if (string.IsNullOrEmpty(stringOut))
                {
                    stringOut = "";
                }
                InOut.SetOutput(stringOut);
            }
            return null;
        }
    }
}
