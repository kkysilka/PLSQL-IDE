﻿using System.Collections.Generic;

namespace Plsql
{
    class ConcatFunction : Function
    {
        private IList<Value> parameterList;

        public ConcatFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new StringValue());
            parameterList.Add(new StringValue());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (!TestParams(parameterList, ex.parameterList))
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            StringValue v1 = ex.parameterList[0] as StringValue;
            StringValue v2 = ex.parameterList[1] as StringValue;
            return new StringValue(v1.Value + v2.Value);
        }
    }
}
