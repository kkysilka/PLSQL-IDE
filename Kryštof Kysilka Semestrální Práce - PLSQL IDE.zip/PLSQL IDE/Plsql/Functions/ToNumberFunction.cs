﻿using System.Collections.Generic;
using System.Globalization;

namespace Plsql
{
    class ToNumberFunction : Function
    {
        private IList<Value> parameterList;

        public ToNumberFunction(string identifier) : base(identifier)
        {
            parameterList = new List<Value>();
            parameterList.Add(new StringValue());
        }

        public override Value Execute(ExecutionContext ex)
        {
            if (!TestParams(parameterList, ex.parameterList))
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            StringValue v = ex.parameterList[0] as StringValue;

            bool isNumber = double.TryParse(v.Value, System.Globalization.NumberStyles.Any, CultureInfo.InvariantCulture, out double n);
            if (!isNumber)
            {
                throw new FunctionHasIncorrectParameterDataTypeException();
            }

            return new NumberValue(n);
        }
    }
}
