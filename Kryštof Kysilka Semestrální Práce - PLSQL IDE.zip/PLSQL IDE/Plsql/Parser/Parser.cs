﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    public class Parser
    {
        private IList<Token> tokenList;
        private bool isUnary = false;
        private int pointer;
        private Statement mainBlock;
        private List<Function> functionList = new List<Function>();
        private IList<InputStatement> inputStatementList;
        private OperatorToken unaryOperator;

        public delegate void ExceptionEventHandler(object source, ExceptionEventArgs args);
        public event ExceptionEventHandler ExceptionThrown;


        public Program Parse(IList<Token> tokenList)
        {

            this.tokenList = tokenList;
            pointer = 0;

            if (tokenList.Count == 0)
            {
                return null;
            }

            try
            {
                functionList.AddRange(LibraryFunctions.GetLibraryFunctions());
                ReadFunctions();

                inputStatementList = ReadInput();

                mainBlock = ReadBlock();
                pointer++;
                pointer++;
                ReadFunctions();
                return new Program(mainBlock, functionList, inputStatementList);
            }
            catch (Exception e)
            {
                OnExceptionThrown(e);
                return null;
            }
        }

        private Statement ReadStatement()
        {
            Statement returnStatement = null;
            switch (GetTokenType())
            {
                case "Identifier":
                    if (GetTokenType(1).Equals("LeftBracket"))
                    {
                        returnStatement = ReadCallStatement();
                        break;
                    }
                    returnStatement = ReadSetStatement();
                    break;
                case "If":
                    returnStatement = ReadIfStatement();
                    break;
                case "While":
                    returnStatement = ReadWhileStatement();
                    break;
                case "Declare":
                    returnStatement = ReadBlock();
                    break;
                case "Begin":
                    returnStatement = ReadBeginEndStatement();
                    break;
                case "Return":
                    returnStatement = ReadReturnStatement();
                    break;
                case "For":
                    returnStatement = ReadForStatement();
                    break;
                default:
                    throw new Exception("Invalid statement token, got " + GetTokenType());
            }
            pointer++;
            CheckTokenType("Semicolon");
            return returnStatement;
        }

        private Statement ReadBlock()
        {
            IList<Variable> variableList = null;
            IList<SetStatement> variableSetList = null; ;
            Statement statement = null;

            if (GetTokenType() == "Declare")
            {
                pointer++;
                ReadDeclare(out variableList, out variableSetList);
            }

            CheckTokenType("Begin");
            statement = ReadStatement();
            pointer--;
            return new BlockStatement(variableSetList, variableList, statement);
        }

        private void ReadDeclare(out IList<Variable> variableList, out IList<SetStatement> statementList)
        {
            variableList = new List<Variable>();
            statementList = new List<SetStatement>();

            while (true)
            {
                bool constant = false;
                bool str = false;
                int strSize = -1;
                string s;

                if (GetTokenType() == "Begin")
                {
                    break;
                }

                CheckTokenType("Identifier");
                IdentifierToken it = (IdentifierToken)tokenList[pointer];
                pointer++;

                s = GetTokenType();
                if (s.Equals("Constant"))
                {
                    constant = true;
                    pointer++;
                }

                CheckDataType();

                s = GetTokenType();
                if (s.Equals("Varchar2"))
                {
                    str = true;
                }
                pointer++;


                if (str)
                {
                    CheckTokenType("LeftBracket");
                    pointer++;

                    CheckTokenType("Number");
                    NumberToken t = (NumberToken)tokenList[pointer];
                    strSize = (int)t.Value;
                    pointer++;

                    CheckTokenType("RightBracket");
                    pointer++;
                }

                if (!constant)
                {
                    s = GetTokenType();
                    if (s.Equals("Semicolon"))
                    {
                        if (str)
                        {
                            variableList.Add(new StringVariable(it.Name, string.Empty, constant, strSize));
                        }
                        else
                        {
                            variableList.Add(new NumberVariable(it.Name, double.NaN, constant));
                        }
                        pointer++;
                        continue;
                    }
                }

                CheckTokenType("Equals");
                pointer++;

                Expression ex = ReadExpression();

                if (str)
                {
                    variableList.Add(new StringVariable(it.Name, string.Empty, constant, strSize));
                }
                else
                {
                    variableList.Add(new NumberVariable(it.Name, double.NaN, constant));
                }

                if (constant)
                {
                    statementList.Add(new SetStatement(it.Name, ex, true));
                }
                else
                {
                    statementList.Add(new SetStatement(it.Name, ex));
                }


                CheckTokenType("Semicolon");
                pointer++;
            }

            if (variableList.Count == 0)
            {
                variableList = null;
            }

            if (statementList.Count == 0)
            {
                statementList = null;
            }
        }

        private SetStatement ReadSetStatement()
        {
            string id = (tokenList[pointer] as IdentifierToken).Name;
            pointer++;

            CheckTokenType("Equals");
            pointer++;

            Expression ex = ReadExpression();
            pointer--;

            return new SetStatement(id, ex);
        }

        private IfStatement ReadIfStatement()
        {
            IList<Statement> mainList = new List<Statement>();
            IList<Statement> secList;
            IList<IfStatement> ifList = new List<IfStatement>();
            IList<Statement> elseList = new List<Statement>();
            pointer++;
            Condition co = ReadCondition();

            CheckTokenType("Then");
            pointer++;

            mainList.Add(ReadStatement());
            CheckTokenType("Semicolon");
            pointer++;

            while (GetTokenType() != "Else" && GetTokenType() != "Elsif" && GetTokenType() != "End")
            {
                mainList.Add(ReadStatement());
                CheckTokenType("Semicolon");
                pointer++;
            }

            while (GetTokenType() == "Elsif")
            {
                pointer++;
                Condition secCon = ReadCondition();

                CheckTokenType("Then");
                pointer++;

                secList = new List<Statement>();

                secList.Add(ReadStatement());
                CheckTokenType("Semicolon");
                pointer++;

                while (GetTokenType() != "End" && GetTokenType() != "Else" && GetTokenType() != "Elsif")
                {
                    secList.Add(ReadStatement());
                    CheckTokenType("Semicolon");
                    pointer++;
                }

                ifList.Add(new IfStatement(secCon, secList, null, null));
            }

            if (GetTokenType() == "Else")
            {
                pointer++;

                elseList.Add(ReadStatement());
                CheckTokenType("Semicolon");
                pointer++;

                while (GetTokenType() != "End")
                {
                    elseList.Add(ReadStatement());
                    CheckTokenType("Semicolon");
                    pointer++;
                }
            }

            pointer++;
            CheckTokenType("If");

            if (ifList.Count == 0)
            {
                ifList = null;
            }
            if (elseList.Count == 0)
            {
                elseList = null;
            }

            return new IfStatement(co, mainList, ifList, elseList);
        }

        private WhileStatement ReadWhileStatement()
        {
            IList<Statement> statementList = new List<Statement>();
            pointer++;
            Condition co = ReadCondition();

            CheckTokenType("Loop");
            pointer++;

            statementList.Add(ReadStatement());
            CheckTokenType("Semicolon");
            pointer++;

            while (GetTokenType() != "End")
            {
                statementList.Add(ReadStatement());
                CheckTokenType("Semicolon");
                pointer++;
            }

            pointer++;
            CheckTokenType("Loop");

            return new WhileStatement(co, statementList);
        }

        private InputStatement ReadInputStatement()
        {
            string id;
            KeywordType dataType;

            CheckTokenType("Accept");
            pointer++;

            CheckTokenType("Identifier");
            id = (tokenList[pointer] as IdentifierToken).Name;
            pointer++;

            if (CheckDataType() == KeywordType.Number || CheckDataType() == KeywordType.Char)
            {
                dataType = CheckDataType();
            }
            else
            {
                throw new InvalidOperationException();
            }

            pointer++;
            CheckTokenType("Prompt");
            pointer++;
            CheckTokenType("String");
            string prompt = (tokenList[pointer] as StringToken).Value;
            pointer++;

            return new InputStatement(id, prompt, dataType);
        }

        private ReturnStatement ReadReturnStatement()
        {
            pointer++;
            if (GetTokenType() == "Semicolon")
            {
                pointer--;
                return new ReturnStatement(null);
            }
            ReturnStatement r = new ReturnStatement(ReadExpression());
            pointer--;
            return r;
        }

        private BeginEndStatement ReadBeginEndStatement()
        {
            pointer++;
            IList<Statement> list = new List<Statement>();

            list.Add(ReadStatement());
            CheckTokenType("Semicolon");
            pointer++;

            while (GetTokenType() != "End")
            {
                list.Add(ReadStatement());
                CheckTokenType("Semicolon");
                pointer++;
            }

            return new BeginEndStatement(list);
        }

        private CallStatement ReadCallStatement()
        {
            string s;
            string id = (tokenList[pointer] as IdentifierToken).Name;
            IList<Expression> expressionList = new List<Expression>();
            pointer++;

            s = GetTokenType();
            if (s.Equals("LeftBracket"))
            {
                pointer++;
                if (GetTokenType() != "RightBracket")
                {
                    expressionList.Add(ReadExpression());
                }

                while (GetTokenType() != "RightBracket")
                {
                    CheckTokenType("Comma");
                    pointer++;
                    expressionList.Add(ReadExpression());
                }
            }

            if (expressionList.Count == 0)
            {
                expressionList = null;
            }

            return new CallStatement(id, expressionList);
        }

        private ForStatement ReadForStatement()
        {
            IList<Statement> statementList = new List<Statement>();
            pointer++;

            string id = (tokenList[pointer] as IdentifierToken).Name;
            pointer++;

            CheckTokenType("In");
            pointer++;

            int from = Convert.ToInt32((tokenList[pointer] as NumberToken).Value);
            pointer++;

            CheckTokenType("FromTo");
            pointer++;

            int to = Convert.ToInt32((tokenList[pointer] as NumberToken).Value);
            pointer++;

            CheckTokenType("Loop");
            pointer++;

            statementList.Add(ReadStatement());
            CheckTokenType("Semicolon");
            pointer++;

            while (GetTokenType() != "End")
            {
                statementList.Add(ReadStatement());
                CheckTokenType("Semicolon");
                pointer++;
            }

            CheckTokenType("End");

            pointer++;
            CheckTokenType("Loop");

            return new ForStatement(statementList, id, from, to);
        }

        private void ReadFunctions()
        {
            while (pointer < tokenList.Count - 1 && GetTokenType() == "Create")
            {
                functionList.Add(ReadFunction());
            }
        }

        private CustomFunction ReadFunction()
        {
            string id;
            string s;
            bool replace = false;
            IList<Variable> variableList = null;
            IList<SetStatement> variableSetList = null;
            Statement statement = null;
            IList<Variable> parameterList = new List<Variable>();
            Expression returnValue;
            KeywordType returnType;

            CheckTokenType("Create");
            pointer++;

            s = GetTokenType();
            if (s.Equals("Or"))
            {
                pointer++;
                CheckTokenType("Replace");
                pointer++;
                replace = true;
            }

            CheckTokenType("Function");
            pointer++;

            CheckTokenType("Identifier");
            id = (tokenList[pointer] as IdentifierToken).Name;
            pointer++;

            s = GetTokenType();
            if (s.Equals("LeftBracket"))
            {
                pointer++;

                string paramId;
                CheckTokenType("Identifier");
                paramId = (tokenList[pointer] as IdentifierToken).Name;
                pointer++;

                KeywordType paramType;
                paramType = CheckDataType();
                pointer++;


                if (paramType == KeywordType.Varchar2)
                {
                    parameterList.Add(new StringVariable(paramId, null, true, -1));
                }
                else
                {
                    parameterList.Add(new NumberVariable(paramId, double.NaN, true));
                }

                while (GetTokenType() != "RightBracket")
                {
                    CheckTokenType("Comma");
                    pointer++;

                    CheckTokenType("Identifier");
                    paramId = (tokenList[pointer] as IdentifierToken).Name;
                    pointer++;

                    paramType = CheckDataType();
                    pointer++;

                    if (paramType == KeywordType.Varchar2)
                    {
                        parameterList.Add(new StringVariable(paramId, null, true, -1));
                    }
                    else
                    {
                        parameterList.Add(new NumberVariable(paramId, double.NaN, true));
                    }
                }

                CheckTokenType("RightBracket");
                pointer++;
            }

            CheckTokenType("Return");
            pointer++;

            returnType = CheckDataType();
            pointer++;

            CheckTokenType("Is");
            pointer++;

            ReadDeclare(out variableList, out variableSetList);

            CheckTokenType("Begin");
            statement = ReadStatement();

            CheckTokenType("Semicolon");
            pointer++;

            foreach (var item in functionList)
            {
                if (item.Identifier == id)
                {
                    if (replace)
                    {
                        functionList.Remove(item);
                        break;
                    }
                    else
                    {
                        throw new FunctionAlreadyExistsException();
                    }
                }
            }

            return new CustomFunction(id, variableSetList, variableList, statement, parameterList, returnType);
        }

        private IList<InputStatement> ReadInput()
        {
            IList<InputStatement> inputList = new List<InputStatement>();

            while (GetTokenType() == "Accept")
            {
                inputList.Add(ReadInputStatement());
                CheckTokenType("Semicolon");
                pointer++;
            }

            if (inputList.Count == 0)
            {
                inputList = null;
            }
            return inputList;
        }

        private Condition ReadCondition()
        {
            bool not = false;
            if (GetTokenType() == "Not")
            {
                not = true;
                pointer++;
            }

            Expression a = ReadExpression();
            OperatorToken ot = (OperatorToken)tokenList[pointer];
            pointer++;
            Expression b = ReadExpression();

            switch (ot.OperatorType)
            {
                case OperatorType.EqualTo:
                    return new EqualToCondition(a, b, not);
                case OperatorType.LessThan:
                    return new LessThanCondition(a, b, not);
                case OperatorType.GreaterThan:
                    return new GreaterThanCondition(a, b, not);
                case OperatorType.LessThanOrEqualTo:
                    return new LessThanOrEqualToCondition(a, b, not);
                case OperatorType.GreaterThanOrEqualTo:
                    return new GreaterThanOrEqualToCondition(a, b, not);
                case OperatorType.NotEqualTo:
                    return new NotEqualToCondition(a, b, not);
            }
            throw new NotImplementedException();
        }

        private Expression ReadExpression()
        {
            isUnary = false;
            Stack<Expression> stack = new Stack<Expression>();

            LoadExpression(stack);

            Expression res = stack.Pop();
            return res;
        }

        private bool LoadExpression(Stack<Expression> stack)
        {
            OperatorToken opPM = null;

            opPM = LoadPlusMinus();
            if (opPM != null)
            {
                isUnary = true;
                unaryOperator = opPM;
                opPM = null;
            }


            while (LoadTerm(stack))
            {
                if (opPM != null)
                {
                    Expression x = (Expression)stack.Pop();
                    Expression y = (Expression)stack.Pop();
                    BinaryExpression res = new BinaryExpression(y, x, opPM);
                    stack.Push(res);
                    opPM = null;
                }

                opPM = LoadPlusMinus();
                if (opPM == null)
                {
                    return true;
                }
            }
            return false;
        }

        private bool LoadTerm(Stack<Expression> stack)
        {
            OperatorToken opTD = null;
            while (LoadFactor(stack))
            {
                if (opTD != null)
                {
                    Expression x = (Expression)stack.Pop();
                    Expression y = (Expression)stack.Pop();

                    BinaryExpression res = new BinaryExpression(y, x, opTD);
                    stack.Push(res);
                    opTD = null;
                }

                opTD = LoadTimesDevide();
                if (opTD == null)
                {
                    return true;
                }
            }
            return false;
        }

        private bool LoadFactor(Stack<Expression> stack)
        {
            if (pointer == tokenList.Count)
            {
                return false;
            }

            if (GetTokenType() == "LeftBracket")
            {
                pointer++;
                Expression nestedExpression = ReadExpression();
                CheckTokenType("RightBracket");
                stack.Push(nestedExpression);
                pointer++;
                return true;
            }


            if (tokenList[pointer] is NumberToken || tokenList[pointer] is StringToken || tokenList[pointer] is IdentifierToken)
            {
                Expression expression = null;

                if (tokenList[pointer] is IdentifierToken)
                {
                    if (GetTokenType(1) == "LeftBracket")
                    {
                        List<Expression> expressionList = new List<Expression>();
                        string id = (tokenList[pointer] as IdentifierToken).Name;
                        pointer++;
                        CheckTokenType("LeftBracket");
                        pointer++;
                        if (GetTokenType() != "RightBracket")
                        {
                            while (true)
                            {
                                expressionList.Add(ReadExpression());
                                if (GetTokenType() == "RightBracket")
                                {
                                    break;
                                }
                                CheckTokenType("Comma");
                                pointer++;
                            }
                        }

                        expression = new FunctionExpression(id, expressionList);
                    }
                    else
                    {
                        if ((tokenList[pointer] as IdentifierToken).Name.StartsWith('&'))
                        {
                            expression = new LiteralExpression(new NumberValue(0), true, (tokenList[pointer] as IdentifierToken).Name);
                        }
                        else
                        {
                            expression = new IdentifierExpression((tokenList[pointer] as IdentifierToken).Name);
                        }
                    }
                }
                else
                {
                    if (tokenList[pointer] is StringToken)
                    {
                        expression = new LiteralExpression(new StringValue((tokenList[pointer] as StringToken).Value));
                    }
                    else
                    {
                        expression = new LiteralExpression(new NumberValue((tokenList[pointer] as NumberToken).Value));
                    }
                }

                if (isUnary)
                {
                    UnaryExpression ux = new UnaryExpression(expression, unaryOperator);
                    isUnary = false;
                    stack.Push(ux);
                }
                else
                {
                    stack.Push(expression);
                }

                pointer++;
                return true;
            }
            else
            {
                return false;
            }
        }

        private OperatorToken LoadPlusMinus()
        {
            if (pointer == tokenList.Count)
            {
                return null;
            }

            if (tokenList[pointer] is OperatorToken)
            {
                OperatorToken o = (OperatorToken)tokenList[pointer];

                if (IsComparisonOperator(o.OperatorType))
                {
                    return null;
                }

                if (o.OperatorType == OperatorType.Plus || o.OperatorType == OperatorType.Minus || o.OperatorType == OperatorType.Concat)
                {
                    pointer++;
                    return o;
                }
            }
            return null;
        }

        private OperatorToken LoadTimesDevide()
        {
            if (pointer == tokenList.Count)
            {
                return null;
            }

            if (tokenList[pointer] is OperatorToken)
            {
                OperatorToken o = (OperatorToken)tokenList[pointer];

                if (IsComparisonOperator(o.OperatorType))
                {
                    return null;
                }

                if (o.OperatorType == OperatorType.Times || o.OperatorType == OperatorType.Devide)
                {
                    pointer++;
                    return o;
                }
            }
            return null;
        }

        private bool IsComparisonOperator(OperatorType ot)
        {
            if (ot == OperatorType.GreaterThan || ot == OperatorType.LessThan ||
                ot == OperatorType.GreaterThanOrEqualTo || ot == OperatorType.LessThanOrEqualTo ||
                ot == OperatorType.Equals || ot == OperatorType.NotEqualTo)
            {
                return true;
            }
            return false;
        }

        private string GetTokenType()
        {
            if (pointer > tokenList.Count - 1)
            {
                throw new UnexpectedTokenException("Unexpected end");
            }

            if (tokenList[pointer] is KeywordToken)
            {
                KeywordToken kt = (KeywordToken)tokenList[pointer];
                return kt.KeywordType.ToString();
            }

            if (tokenList[pointer] is OperatorToken)
            {
                OperatorToken ot = (OperatorToken)tokenList[pointer];
                return ot.OperatorType.ToString();
            }

            if (tokenList[pointer] is SeparatorToken)
            {
                SeparatorToken st = (SeparatorToken)tokenList[pointer];
                return st.SeparatorType.ToString();
            }

            if (tokenList[pointer] is NumberToken)
            {
                return "Number";
            }

            if (tokenList[pointer] is StringToken)
            {
                return "String";
            }

            if (tokenList[pointer] is IdentifierToken)
            {
                return "Identifier";
            }

            return null;
        }

        private string GetTokenType(int indexDif)
        {
            if (pointer > tokenList.Count - 1 || pointer + indexDif > tokenList.Count - 1)
            {
                throw new UnexpectedTokenException("Unexpected end");
            }

            if (tokenList[pointer + indexDif] is KeywordToken)
            {
                KeywordToken kt = (KeywordToken)tokenList[pointer + indexDif];
                return kt.KeywordType.ToString();
            }

            if (tokenList[pointer + indexDif] is OperatorToken)
            {
                OperatorToken ot = (OperatorToken)tokenList[pointer + indexDif];
                return ot.OperatorType.ToString();
            }

            if (tokenList[pointer + indexDif] is SeparatorToken)
            {
                SeparatorToken st = (SeparatorToken)tokenList[pointer + indexDif];
                return st.SeparatorType.ToString();
            }

            if (tokenList[pointer + indexDif] is NumberToken)
            {
                return "Number";
            }

            if (tokenList[pointer + indexDif] is StringToken)
            {
                return "String";
            }

            if (tokenList[pointer + indexDif] is IdentifierToken)
            {
                return "Identifier";
            }

            return null;
        }

        private void CheckTokenType(string tokenType)
        {
            if (pointer > tokenList.Count - 1)
            {
                throw new UnexpectedTokenException("Unexpected end");
            }

            if (GetTokenType() != tokenType)
            {
                throw new UnexpectedTokenException("Unexpected token");
            }
        }

        private KeywordType CheckDataType()
        {
            if (tokenList[pointer] is KeywordToken)
            {
                KeywordToken kt = (KeywordToken)tokenList[pointer];
                if (kt.KeywordType.ToString().Equals("Varchar2"))
                {
                    return KeywordType.Varchar2;
                }
                if (kt.KeywordType.ToString().Equals("Number"))
                {
                    return KeywordType.Number;
                }
                if (kt.KeywordType.ToString().Equals("Char"))
                {
                    return KeywordType.Char;
                }
            }
            throw new UnexpectedTokenException("Unexpected token");
        }

        protected virtual void OnExceptionThrown(Exception e)
        {
            if (ExceptionThrown != null)
            {
                ExceptionThrown(this, new ExceptionEventArgs() { ThrownException = e, Position = pointer + 1 });
            }
        }

    }
}
