﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    public class Program
    {
        private Statement mainBlock;
        private List<Function> functionList = new List<Function>();
        private IList<InputStatement> inputStatementList;

        public delegate void ExceptionEventHandler(object source, ExceptionEventArgs args);
        public event ExceptionEventHandler ExceptionThrown;

        public Program(Statement mainBlock, List<Function> functionList, IList<InputStatement> inputStatementList)
        {
            this.mainBlock = mainBlock;
            this.functionList = functionList;
            this.inputStatementList = inputStatementList;
        }

        public void Execute()
        {
            IList<Variable> inputVariableList = new List<Variable>();
            Variables inputVariables;

            try
            {
                if (inputStatementList != null)
                {
                    foreach (var item in inputStatementList)
                    {
                        Value res = item.Execute(null);
                        if (res is NumberValue)
                        {
                            inputVariableList.Add(new NumberVariable(item.Identifier, (res as NumberValue).Value, true));
                        }
                        else if (res is StringValue)
                        {
                            inputVariableList.Add(new StringVariable(item.Identifier, (res as StringValue).Value, true, int.MaxValue));
                        }
                    }

                    if (inputVariableList.Count == 0)
                    {
                        inputVariables = new Variables();
                    }

                    inputVariables = new Variables(inputVariableList);
                }
                else
                {
                    inputVariables = new Variables();
                }

                ExecutionContext ex = new ExecutionContext(new ProgramContext(functionList), new Variables(), inputVariables, null);
                mainBlock.Execute(ex);
            }
            catch (Exception e)
            {
                OnExceptionThrown(e);
            }
        }

        protected virtual void OnExceptionThrown(Exception e)
        {
            if (ExceptionThrown != null)
            {
                ExceptionThrown(this, new ExceptionEventArgs() { ThrownException = e, Position = -1 });
            }
        }

    }
}
