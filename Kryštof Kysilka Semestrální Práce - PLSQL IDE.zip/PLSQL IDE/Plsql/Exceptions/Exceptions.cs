﻿using System;

namespace Plsql
{
    class VariableDoesNotExistException : Exception
    {
        public VariableDoesNotExistException() : base("Variable does not exist.")
        {
        }

        public VariableDoesNotExistException(string message) : base(message)
        {
        }
    }

    class VariableAlreadyExistsException : Exception
    {
        public VariableAlreadyExistsException() : base("Variable already exists.")
        {
        }

        public VariableAlreadyExistsException(string message) : base(message)
        {
        }
    }

    class VariableIsConstantException : Exception
    {
        public VariableIsConstantException() : base("Variable is constant.")
        {
        }

        public VariableIsConstantException(string message) : base(message)
        {
        }
    }

    class VariableHasIncorrectDataTypeException : Exception
    {
        public VariableHasIncorrectDataTypeException() : base("Variable has incorrect data type.")
        {
        }

        public VariableHasIncorrectDataTypeException(string message) : base(message)
        {
        }
    }

    class VariableHasIncorrectNameException : Exception
    {
        public VariableHasIncorrectNameException() : base("Variable has incorrect name.")
        {
        }

        public VariableHasIncorrectNameException(string message) : base(message)
        {
        }
    }

    class DefineIsNotSupportedInAFunctionException : Exception
    {
        public DefineIsNotSupportedInAFunctionException() : base("Define is not supported in a function.")
        {
        }

        public DefineIsNotSupportedInAFunctionException(string message) : base(message)
        {
        }
    }

    class CharacterStringBufferTooSmallException : Exception
    {
        public CharacterStringBufferTooSmallException() : base("Character string buffer too small.")
        {
        }

        public CharacterStringBufferTooSmallException(string message) : base(message)
        {
        }
    }

    class FunctionDoesNotExistException : Exception
    {
        public FunctionDoesNotExistException() : base("Function does not exist.")
        {
        }

        public FunctionDoesNotExistException(string message) : base(message)
        {
        }
    }

    class FunctionHasToReturnValueException : Exception
    {
        public FunctionHasToReturnValueException() : base("Function has to return value.")
        {
        }

        public FunctionHasToReturnValueException(string message) : base(message)
        {
        }
    }

    class FunctionHasToReturnCorrectDataTypeException : Exception
    {
        public FunctionHasToReturnCorrectDataTypeException() : base("Function has to return correct data type.")
        {
        }

        public FunctionHasToReturnCorrectDataTypeException(string message) : base(message)
        {
        }
    }

    class FunctionHasIncorrectParameterDataTypeException : Exception
    {
        public FunctionHasIncorrectParameterDataTypeException() : base("Function has incorrect parameter data type.")
        {
        }

        public FunctionHasIncorrectParameterDataTypeException(string message) : base(message)
        {
        }
    }

    class FunctionAlreadyExistsException : Exception
    {
        public FunctionAlreadyExistsException() : base("Function already exists.")
        {
        }

        public FunctionAlreadyExistsException(string message) : base(message)
        {
        }
    }

    class UnexpectedTokenException : Exception
    {
        public UnexpectedTokenException() : base("Unexpected token.")
        {
        }

        public UnexpectedTokenException(string message) : base(message)
        {
        }
    }
}
