﻿using System;

namespace Plsql
{
    public class ExceptionEventArgs : EventArgs
    {
        public Exception ThrownException { get; set; }
        public int Position { get; set; }
    }
}
