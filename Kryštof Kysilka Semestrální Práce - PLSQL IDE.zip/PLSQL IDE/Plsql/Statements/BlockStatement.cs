﻿using System.Collections.Generic;
using System.Diagnostics;

namespace Plsql
{
    class BlockStatement : Statement
    {

        private IList<SetStatement> variableSetList;
        private IList<Variable> variableList;
        private Statement statement;


        public BlockStatement(IList<SetStatement> variableSetList, IList<Variable> variableList, Statement statement)
        {
            this.variableSetList = variableSetList;
            this.variableList = variableList;
            this.statement = statement;
        }

        public override Value Execute(ExecutionContext ex)
        {
            Variables variables;

            if (variableList == null && variableSetList == null)
            {
                variables = new Variables();
            }
            else
            {
                variables = new Variables(variableList);
            }

            ExecutionContext executionContext = new ExecutionContext(ex.programContext, variables, ex.inputVariables, ex);

            if (variableList != null && variableSetList != null)
            {
                foreach (var item in variableSetList)
                {
                    item.Execute(executionContext);
                }
            }

            Value v = statement.Execute(executionContext);
            return v;
        }
    }
}
