﻿namespace Plsql
{
    public abstract class Statement
    {
        public abstract Value Execute(ExecutionContext executionContext);
    }
}
