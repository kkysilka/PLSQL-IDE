﻿using System.Collections.Generic;

namespace Plsql
{
    class WhileStatement : Statement
    {
        public Condition Condition { get; private set; }
        public IList<Statement> statementList;

        public WhileStatement(Condition condition, IList<Statement> statementList)
        {
            Condition = condition;
            this.statementList = statementList;
        }

        public override Value Execute(ExecutionContext ex)
        {
            while (Condition.Eval(ex) == true)
            {
                foreach (var item in statementList)
                {
                    Value v = item.Execute(ex);
                    if (v != null && v.Returned == true)
                    {
                        return v;
                    }
                }
            }
            return null;
        }
    }
}
