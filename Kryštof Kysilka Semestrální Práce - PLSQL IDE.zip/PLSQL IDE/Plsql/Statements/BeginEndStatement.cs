﻿using System.Collections.Generic;

namespace Plsql
{
    class BeginEndStatement : Statement
    {
        private IList<Statement> statementList;

        public BeginEndStatement(IList<Statement> statementList)
        {
            this.statementList = statementList;
        }

        public override Value Execute(ExecutionContext executionContext)
        {
            foreach (var item in statementList)
            {
                Value v = item.Execute(executionContext);
                if (v != null && v.Returned == true)
                {
                    return v;
                }
            }
            return null;
        }
    }
}
