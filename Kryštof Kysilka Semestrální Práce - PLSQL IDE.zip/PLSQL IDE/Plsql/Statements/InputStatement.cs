﻿namespace Plsql
{
    public class InputStatement : Statement
    {
        public string Identifier { get; private set; }
        public string Prompt { get; private set; }
        public KeywordType DataType { get; private set; }

        public InputStatement(string identifier, string prompt, KeywordType dataType)
        {
            Identifier = identifier;
            Prompt = prompt;
            DataType = dataType;
        }

        public override Value Execute(ExecutionContext executionContext)
        {
            string consoleInput = InOut.SetInput(Prompt);

            if (DataType == KeywordType.Number)
            {
                if (consoleInput == null)
                {
                    return new NumberValue(0);
                }

                bool parse = double.TryParse(consoleInput, out double input);
                if (!parse)
                {
                    throw new VariableHasIncorrectDataTypeException();
                }
                return new NumberValue(input);
            }
            else if (DataType == KeywordType.Char)
            {
                if (consoleInput == null)
                {
                    return new StringValue("");
                }
                return new StringValue(consoleInput);
            }
            else
            {
                throw new VariableHasIncorrectDataTypeException();
            }
        }
    }
}
