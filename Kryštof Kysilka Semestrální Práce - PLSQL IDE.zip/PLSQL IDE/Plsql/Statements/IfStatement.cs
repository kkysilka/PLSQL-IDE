﻿using System.Collections.Generic;

namespace Plsql
{
    class IfStatement : Statement
    {
        public Condition Condition { get; private set; }
        private IList<Statement> statementList;
        private IList<Statement> elseStatementList;
        private IList<IfStatement> ifStatementList;

        public IfStatement(Condition condition, IList<Statement> statementList, IList<IfStatement> ifStatementList, IList<Statement> elseStatementList)
        {
            Condition = condition;
            this.statementList = statementList;
            this.ifStatementList = ifStatementList;
            this.elseStatementList = elseStatementList;
        }

        public bool TestCondition(ExecutionContext ex)
        {
            return Condition.Eval(ex) == true;
        }

        public override Value Execute(ExecutionContext ex)
        {
            Value v;
            if (Condition.Eval(ex) == true)
            {
                foreach (var item in statementList)
                {
                    v = item.Execute(ex);
                    if (v != null && v.Returned == true)
                    {
                        return v;
                    }
                }
                return null;
            }

            if (ifStatementList != null)
            {
                foreach (var item in ifStatementList)
                {
                    if (item.TestCondition(ex))
                    {
                        v = item.Execute(ex);
                        return v;
                    }
                }
            }

            if (elseStatementList != null)
            {
                foreach (var item in elseStatementList)
                {
                    v = item.Execute(ex);
                    if (v != null)
                    {
                        return v;
                    }
                }
            }
            return null;
        }
    }
}
