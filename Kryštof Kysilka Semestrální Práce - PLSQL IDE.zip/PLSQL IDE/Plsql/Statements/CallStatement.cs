﻿using System.Collections.Generic;

namespace Plsql
{
    class CallStatement : Statement
    {
        public string Identifier { get; private set; }
        private IList<Expression> expressionList;

        public CallStatement(string identifier, IList<Expression> expressionList)
        {
            Identifier = identifier;
            this.expressionList = expressionList;
        }

        public override Value Execute(ExecutionContext executionContext)
        {
            IList<Value> valueList = null;
            if (expressionList != null)
            {
                valueList = new List<Value>();

                foreach (var item in expressionList)
                {
                    valueList.Add(item.Eval(executionContext));
                }
            }

            ExecutionContext ex = new ExecutionContext(executionContext.programContext, null, null, null);
            ex.SetParametrs(valueList);

            if (ex.programContext.Find(Identifier))
            {
                return ex.programContext.Call(Identifier, ex);
            }

            throw new FunctionDoesNotExistException("Function does not exist.");
        }
    }
}
