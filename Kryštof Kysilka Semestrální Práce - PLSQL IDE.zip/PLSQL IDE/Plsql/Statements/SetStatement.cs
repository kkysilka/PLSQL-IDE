﻿namespace Plsql
{
    class SetStatement : Statement
    {
        public string Identifier { get; private set; }
        public Expression Expression { get; private set; }
        public bool Constant { get; private set; }

        public SetStatement(string identifier, Expression expression)
        {
            Identifier = identifier;
            Expression = expression;
        }

        public SetStatement(string identifier, Expression expression, bool constant)
        {
            Identifier = identifier;
            Expression = expression;
            Constant = constant;
        }

        public override Value Execute(ExecutionContext executionContext)
        {
            ExecutionContext ex = executionContext;
            Value val = Expression.Eval(ex);

            if (val is NumberValue)
            {
                while (ex != null)
                {
                    if (ex.variables == null)
                    {
                        ex = ex.upperExecutionContext;
                        continue;
                    }

                    if (Constant)
                    {
                        if (ex.variables.SetConstantVariable(Identifier, (val as NumberValue).Value))
                        {
                            return null;
                        }
                    }
                    else
                    {
                        if (ex.variables.SetVariable(Identifier, (val as NumberValue).Value))
                        {
                            return null;
                        }
                    }

                    ex = ex.upperExecutionContext;
                }
            }
            else
            {
                while (ex != null)
                {
                    if (Constant)
                    {
                        if (ex.variables.SetConstantVariable(Identifier, (val as StringValue).Value))
                        {
                            return null;
                        }
                    }
                    else
                    {
                        if (ex.variables.SetVariable(Identifier, (val as StringValue).Value))
                        {
                            return null;
                        }
                    }

                    ex = ex.upperExecutionContext;
                }
            }
            throw new VariableDoesNotExistException("Variable does not exist or is constant.");
        }
    }
}
