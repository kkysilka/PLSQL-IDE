﻿using System;
using System.Collections.Generic;

namespace Plsql
{
    class ForStatement : Statement
    {
        private IList<Statement> statementList;
        private string identifier;
        private int from;
        private int to;
        private int currValue;

        public ForStatement(IList<Statement> statementList, string identifier, int from, int to)
        {
            this.statementList = statementList;
            this.identifier = identifier;
            this.from = from;
            this.to = to;
            this.currValue = from;
        }

        public override Value Execute(ExecutionContext ex)
        {

            ExecutionContext executionContext = new ExecutionContext(ex.programContext, new Variables(), ex.inputVariables, ex);

            executionContext.variables.AddConstantNumberVariable(identifier, from);

            while ((executionContext.variables.GetVariableValue(identifier) as NumberValue).Value <= to)
            {
                foreach (var item in statementList)
                {
                    item.Execute(executionContext);
                }

                currValue++;
                if (!executionContext.variables.SetConstantVariable(identifier, currValue))
                {
                    throw new ArgumentException();
                }
            }
            return null;
        }
    }
}
