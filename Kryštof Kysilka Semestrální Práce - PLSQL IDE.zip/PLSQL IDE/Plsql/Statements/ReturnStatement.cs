﻿namespace Plsql
{
    class ReturnStatement : Statement
    {
        public Expression Expression { get; private set; }

        public ReturnStatement(Expression expression)
        {
            Expression = expression;
        }

        public override Value Execute(ExecutionContext executionContext)
        {
            Value v;
            if (Expression == null)
            {
                v = new Value();
                v.Returned = true;
                return v;
            }
            v = Expression.Eval(executionContext);
            v.Returned = true;
            return v;
        }
    }
}
