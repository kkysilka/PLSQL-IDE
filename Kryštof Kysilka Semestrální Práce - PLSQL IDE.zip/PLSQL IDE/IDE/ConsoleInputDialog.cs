﻿using System;
using System.Windows.Forms;

namespace UI
{
    public partial class ConsoleInputDialog : Form
    {
        public string Input { get; private set; }
        public bool Next { get; private set; }

        public ConsoleInputDialog(Form parrent)
        {
            this.StartPosition = FormStartPosition.CenterParent;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(inputTextBox.Text.Trim()))
            {
                Input = inputTextBox.Text;
            }
            else
            {
                Input = null;
            }
            Next = true;
            this.Hide();
        }

        public void SetLabel(string label, string title)
        {
            dialogLabel.Text = label;
            this.Text = title;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Next = false;
            this.Hide();
        }

        private void ConsoleInputDialog_Load(object sender, EventArgs e)
        {
            this.ActiveControl = inputTextBox;
        }
    }
}
