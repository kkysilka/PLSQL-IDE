﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Logic;
using Plsql;

namespace UI
{
    public partial class Main : Form
    {
        private IList<string> ProjectFileNames { get; set; }
        private Label activeFile;
        private ContextMenuStrip fileContextMenu;
        private ContextMenuStrip projectContextMenu;

        public Main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            menu.Renderer = new ToolStripProfessionalRenderer(new MenuColors());
            EnableMenuItems(false);
            CreateContextMenuForFiles();
            Files.ExceptionReceived += OnExceptionReceived;
        }

        private void CreateContextMenuForFiles()
        {
            fileContextMenu = new ContextMenuStrip();
            fileContextMenu.Renderer = new ToolStripProfessionalRenderer(new MenuColors());
            fileContextMenu.Items.Add("Rename").ForeColor = Color.White;
            fileContextMenu.Items.Add("Delete").ForeColor = Color.White;
            fileContextMenu.ItemClicked += new ToolStripItemClickedEventHandler(
                FileContextMenu_ItemClicked);

            projectContextMenu = new ContextMenuStrip();
            projectContextMenu.Renderer = new ToolStripProfessionalRenderer(new MenuColors());
            projectContextMenu.Items.Add("Rename").ForeColor = Color.White;
            projectContextMenu.ItemClicked += new ToolStripItemClickedEventHandler(
                ProjectContextMenu_ItemClicked);
        }


        private void menuItemExit_Click(object sender, EventArgs e)
        {
            string message = "Do you want exit the application?";
            string title = "Exit Window";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                Files.ExitIDE();
            }
        }

        private void menuItemNewProject_Click(object sender, EventArgs e)
        {
            NameInputDialog dialog = new NameInputDialog();
            dialog.SetLabel("Project name", "New Project");
            dialog.ShowDialog();
            string projectName = dialog.Input;
            if (string.IsNullOrEmpty(projectName))
            {
                dialog.Dispose();
                return;
            }

            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = false;

            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                bool succ = Logic.Files.NewProject(folderDlg.SelectedPath, projectName);
                if (!succ)
                {
                    MessageBox.Show("Project could not be created.", "New Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                return;
            }

            EnableMenuItems(true);
            CleanUp();
            CreateProjectLabel();
        }

        private void menuItemOpenProject_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = false;

            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                bool open = Files.OpenProject(folderDlg.SelectedPath);
                if (!open)
                {
                    MessageBox.Show("Project could not be opened.", "Open Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                return;
            }

            ProjectFileNames = Files.GetProjectFileNames();

            EnableMenuItems(true);
            CleanUp();
            CreateProjectLabel();

            for (int i = 0; i < ProjectFileNames.Count; i++)
            {
                CreateFileLabel(ProjectFileNames[i], i);
            }
        }

        private void menuItemNewFile_Click(object sender, EventArgs e)
        {
            NameInputDialog dialog = new NameInputDialog();
            dialog.SetLabel("File name", "New File");
            dialog.ShowDialog();
            string fileName = dialog.Input;
            if (string.IsNullOrEmpty(fileName))
            {
                dialog.Dispose();
                return;
            }

            if (!Files.NewFile(fileName))
            {
                MessageBox.Show("File could not be created.", "Create File", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Label label = CreateFileLabel(fileName, Project.FileList.Count - 1);
            labelFile_Click(label, EventArgs.Empty);
        }

        private void menuItemSave_Click(object sender, EventArgs e)
        {
            if (activeFile == null)
            {
                return;
            }

            if (!Files.SaveFile(activeFile.Text, codeEditor.Text))
            {
                MessageBox.Show("File could not be saved.", "Save File", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }

        private void menuItemSaveAll_Click(object sender, EventArgs e)
        {
            if (activeFile != null)
            {
                Files.SaveFileProgress(activeFile.Text, codeEditor.Text);
            }

            foreach (var item in Files.GetProjectFileNames())
            {
                Files.SaveFile(item, Files.GetFileText(item));
            }
        }


        private void labelFile_MouseEnter(object sender, EventArgs e)
        {
            Label label = (Label)sender;
            if (label.Equals(activeFile))
            {
                label.BackColor = Color.FromArgb(64, 64, 64);
                return;
            }
            label.BackColor = Color.FromArgb(54, 54, 54);
        }

        private void labelFile_MouseLeave(object sender, EventArgs e)
        {
            Label label = (Label)sender;
            if (label.Equals(activeFile))
            {
                label.BackColor = Color.FromArgb(64, 64, 64);
                return;
            }
            label.BackColor = Color.FromArgb(48, 48, 48);

        }

        private void labelFile_Click(object sender, EventArgs e)
        {
            Label label = (Label)sender;

            ProjectFileNames = Files.GetProjectFileNames();

            if (ProjectFileNames.Contains(label.Text))
            {
                if (activeFile != null)
                {
                    Files.SaveFileProgress(activeFile.Text, codeEditor.Text);
                }

                codeEditor.Clear();
                codeEditor.Text = Files.GetFileText(label.Text);
            }

            if (activeFile != null)
            {
                activeFile.BackColor = Color.FromArgb(48, 48, 48);
            }
            activeFile = label;
            activeFile.BackColor = Color.FromArgb(64, 64, 64);
            codeEditor.Enabled = true;
        }

        private void labelFile_DoubleClick(object sender, EventArgs e)
        {
            Label label = (Label)sender;
            string fileName = label.Text;

            Rename(fileName, label);
        }


        private Label CreateFileLabel(string fileName, int position)
        {
            Label label = new Label();
            label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label.ForeColor = System.Drawing.Color.White;
            label.Location = new System.Drawing.Point(0, (1 + position) * 20);
            label.Name = "labelFile" + position;
            label.Size = new System.Drawing.Size(194, 20);
            label.Padding = new System.Windows.Forms.Padding(25, 3, 0, 0);
            label.Text = fileName;
            label.ContextMenuStrip = fileContextMenu;
            label.Click += new System.EventHandler(labelFile_Click);
            label.DoubleClick += new System.EventHandler(labelFile_DoubleClick);
            label.MouseEnter += new System.EventHandler(labelFile_MouseEnter);
            label.MouseLeave += new System.EventHandler(labelFile_MouseLeave);
            panelFiles.Controls.Add(label);
            return label;
        }

        private Label CreateProjectLabel()
        {
            Label label = new Label();
            label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label.ForeColor = System.Drawing.Color.White;
            label.Location = new System.Drawing.Point(0, 0);
            label.Name = "labelProject";
            label.Size = new System.Drawing.Size(194, 20);
            label.Padding = new System.Windows.Forms.Padding(5, 3, 0, 0);
            label.Text = Project.Name;
            label.ContextMenuStrip = projectContextMenu;
            label.MouseEnter += new System.EventHandler(labelFile_MouseEnter);
            label.MouseLeave += new System.EventHandler(labelFile_MouseLeave);
            panelFiles.Controls.Add(label);
            return label;
        }

        private void EnableMenuItems(bool opened)
        {
            if (opened)
            {
                menuItemNewFile.Enabled = true;
                menuItemSave.Enabled = true;
                menuItemSaveAll.Enabled = true;
            }
            else
            {
                menuItemNewFile.Enabled = false;
                menuItemSave.Enabled = false;
                menuItemSaveAll.Enabled = false;
                codeEditor.Enabled = false;
            }
        }

        private void CleanUp()
        {
            panelFiles.Controls.Clear();
            codeEditor.Clear();
            consoleTextBox.Clear();
            activeFile = null;
            codeEditor.Enabled = false;
        }


        void FileContextMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            Label label = (Label)fileContextMenu.SourceControl;
            string fileName = label.Text;
            ToolStripItem item = e.ClickedItem;

            if (item.Text.Equals("Rename"))
            {
                Rename(fileName, label);
            }
            else
            {
                string message = "Do you want to delete file '" + fileName + "' ?";
                string title = "Delete File";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, title, buttons);
                if (result == DialogResult.Yes)
                {
                    if (!Files.DeleteFile(fileName))
                    {
                        MessageBox.Show("File could not be deleted.", "Delete File", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    EnableMenuItems(true);
                    CleanUp();
                    CreateProjectLabel();

                    ProjectFileNames = Files.GetProjectFileNames();

                    for (int i = 0; i < ProjectFileNames.Count; i++)
                    {
                        CreateFileLabel(ProjectFileNames[i], i);
                    }
                }
                else
                {
                    return;
                }
            }
        }

        void ProjectContextMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            Label label = (Label)projectContextMenu.SourceControl;
            string projectName = label.Text;
            ToolStripItem item = e.ClickedItem;

            if (item.Text.Equals("Rename"))
            {
                NameInputDialog dialog = new NameInputDialog();
                dialog.SetLabel("Project name", "Rename Project");
                dialog.SetButton("Rename", "Cancel");
                dialog.SetInput(projectName);
                dialog.ShowDialog();
                string newProjectName = dialog.Input;
                if (string.IsNullOrEmpty(newProjectName))
                {
                    dialog.Dispose();
                    return;
                }

                if (!Files.RenameProject(newProjectName))
                {
                    MessageBox.Show("Project could not be renamed.", "Rename Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                label.Text = newProjectName;
            }
        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            RunProgram();
        }

        public void Output(string output)
        {
            if (consoleTextBox.Lines.Length != 0)
            {
                consoleTextBox.AppendText("\r\n");
            }
            consoleTextBox.AppendText(output);
        }

        public string Input(string textToDisplay)
        {
            ConsoleInputDialog dialog = new ConsoleInputDialog(this);
            dialog.SetLabel(textToDisplay, "Enter Value");
            dialog.ShowDialog();
            if (!dialog.Next)
            {
                throw new ArgumentException();
            }
            return dialog.Input;
        }

        private void menuItemRun_Click(object sender, EventArgs e)
        {
            RunProgram();
        }

        private void RunProgram()
        {
            if (activeFile != null)
            {
                Files.SaveFileProgress(activeFile.Text, codeEditor.Text);
            }

            if (Project.FileList == null)
            {
                return;
            }

            StringBuilder sb = new StringBuilder();
            foreach (var item in Project.FileList)
            {
                sb.Append(item.Text);
            }
            string input = sb.ToString();

            consoleTextBox.Clear();

            Files.Run(input, this.Output, this.Input);
        }

        private void Rename(string fileName, Label label)
        {
            NameInputDialog dialog = new NameInputDialog();
            dialog.SetLabel("File name", "Rename File");
            dialog.SetButton("Rename", "Cancel");
            dialog.SetInput(fileName);
            dialog.ShowDialog();
            string newFileName = dialog.Input;
            if (string.IsNullOrEmpty(newFileName))
            {
                dialog.Dispose();
                return;
            }

            if (!Files.RenameFile(fileName, newFileName))
            {
                MessageBox.Show("File could not be renamed.", "Rename File", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            label.Text = newFileName;
        }

        public static void OnExceptionReceived(object source, ExceptionEventArgs e)
        {
            ExceptionDialog exceptionDialog = new ExceptionDialog();
            if (e.Position < 0)
            {
                exceptionDialog.SetText(e.ThrownException.Message);
            }
            else
            {
                exceptionDialog.SetText(e.ThrownException.Message + " on position : " + e.Position);
            }
            exceptionDialog.ShowDialog();
        }

        private void menuItemSample1_Click(object sender, EventArgs e)
        {
            LoadSample("Sample Project 1");
        }

        private void menuItemSample2_Click(object sender, EventArgs e)
        {
            LoadSample("Sample Project 2");
        }

        private void menuItemSample3_Click(object sender, EventArgs e)
        {
            LoadSample("Sample Project 3");
        }

        private void LoadSample(string sampleName)
        {

            bool open = Files.OpenProject("../../../../SampleProjects/" + sampleName);
            if (!open)
            {
                MessageBox.Show("Project could not be opened.", "Open Project", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ProjectFileNames = Files.GetProjectFileNames();

            EnableMenuItems(true);
            CleanUp();
            CreateProjectLabel();

            for (int i = 0; i < ProjectFileNames.Count; i++)
            {
                CreateFileLabel(ProjectFileNames[i], i);
            }
        }

        private void menuItemAbout_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }
    }
}
