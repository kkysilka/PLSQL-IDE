﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UI
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

        private void About_Load(object sender, EventArgs e)
        {

            //string fileText = System.IO.File.ReadAllText("../../../../readme.txt");

            string fileText = "";
            string[] lines = System.IO.File.ReadAllLines("../../../../readme.txt");

            foreach (string line in lines)
            {
                fileText += line + "\r\n";
            }


            aboutTextBox.Text = fileText;
        }
    }
}
