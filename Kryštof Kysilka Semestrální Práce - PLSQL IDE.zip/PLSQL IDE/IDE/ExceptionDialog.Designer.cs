﻿
namespace UI
{
    partial class ExceptionDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exceptionThrownText = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.exceptionText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exceptionThrownText
            // 
            this.exceptionThrownText.AutoSize = true;
            this.exceptionThrownText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.exceptionThrownText.ForeColor = System.Drawing.Color.White;
            this.exceptionThrownText.Location = new System.Drawing.Point(10, 20);
            this.exceptionThrownText.Name = "exceptionThrownText";
            this.exceptionThrownText.Size = new System.Drawing.Size(115, 15);
            this.exceptionThrownText.TabIndex = 9;
            this.exceptionThrownText.Text = "Exception occurred :";
            // 
            // okButton
            // 
            this.okButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.okButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.okButton.FlatAppearance.BorderSize = 2;
            this.okButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.okButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.okButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.okButton.ForeColor = System.Drawing.Color.White;
            this.okButton.Location = new System.Drawing.Point(114, 75);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(63, 26);
            this.okButton.TabIndex = 10;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = false;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // exceptionText
            // 
            this.exceptionText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.exceptionText.ForeColor = System.Drawing.Color.White;
            this.exceptionText.Location = new System.Drawing.Point(12, 46);
            this.exceptionText.Name = "exceptionText";
            this.exceptionText.Size = new System.Drawing.Size(269, 15);
            this.exceptionText.TabIndex = 11;
            this.exceptionText.Text = "Prompt";
            this.exceptionText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ExceptionDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(293, 112);
            this.Controls.Add(this.exceptionText);
            this.Controls.Add(this.exceptionThrownText);
            this.Controls.Add(this.okButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Location = new System.Drawing.Point(14, 41);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(309, 151);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(309, 151);
            this.Name = "ExceptionDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Exception Thrown";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label exceptionThrownText;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label exceptionText;
    }
}