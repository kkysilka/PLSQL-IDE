﻿using System;
using System.Windows.Forms;

namespace UI
{
    public partial class ExceptionDialog : Form
    {
        public ExceptionDialog()
        {
            InitializeComponent();
        }

        public void SetText(string text)
        {
            exceptionText.Text = text;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
