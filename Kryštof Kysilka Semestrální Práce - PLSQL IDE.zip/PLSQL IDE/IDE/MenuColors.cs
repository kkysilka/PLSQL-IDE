﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace UI
{
    class MenuColors : ProfessionalColorTable
    {

        private Color mainColor = Color.FromArgb(38, 38, 38);
        private Color selectedColor = Color.FromArgb(64, 64, 64);

        public override Color ToolStripDropDownBackground
        {
            get
            {
                return mainColor;
            }
        }

        public override Color ImageMarginGradientBegin
        {
            get
            {
                return mainColor;
            }
        }

        public override Color CheckBackground
        {
            get
            {
                return Color.Red;
            }
        }

        public override Color ImageMarginGradientMiddle
        {
            get
            {
                return mainColor;
            }
        }

        public override Color ImageMarginGradientEnd
        {
            get
            {
                return mainColor;
            }
        }

        public override Color MenuBorder
        {
            get
            {
                return mainColor;
            }
        }

        public override Color MenuItemBorder
        {
            get
            {
                return selectedColor;
            }
        }

        public override Color MenuItemSelected
        {
            get
            {
                return selectedColor;
            }
        }

        public override Color MenuStripGradientBegin
        {
            get
            {
                return mainColor;
            }
        }

        public override Color MenuStripGradientEnd
        {
            get
            {
                return mainColor;
            }
        }

        public override Color MenuItemSelectedGradientBegin
        {
            get
            {
                return selectedColor;
            }
        }

        public override Color MenuItemSelectedGradientEnd
        {
            get
            {
                return selectedColor;
            }
        }

        public override Color MenuItemPressedGradientBegin
        {
            get
            {
                return mainColor;
            }
        }

        public override Color MenuItemPressedGradientEnd
        {
            get
            {
                return mainColor;
            }
        }
    }
}
