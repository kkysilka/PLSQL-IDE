﻿using System;
using System.Windows.Forms;

namespace UI
{
    public partial class Console : Form
    {
        public Console()
        {
            InitializeComponent();
        }

        private void Console_Load(object sender, EventArgs e)
        {
            this.CenterToParent();
        }

        public void Output(string output)
        {
            if (consoleTextBox.Lines.Length != 0)
            {
                consoleTextBox.AppendText("\r\n");
            }
            consoleTextBox.AppendText(output);
        }

        public string Input(string textToDisplay)
        {
            ConsoleInputDialog dialog = new ConsoleInputDialog(this);
            dialog.SetLabel(textToDisplay, "Enter Value");
            dialog.ShowDialog();
            if (!dialog.Next)
            {
                throw new ArgumentException();
            }
            return dialog.Input;
        }

        public void Clear()
        {
            consoleTextBox.Clear();
        }
    }
}
