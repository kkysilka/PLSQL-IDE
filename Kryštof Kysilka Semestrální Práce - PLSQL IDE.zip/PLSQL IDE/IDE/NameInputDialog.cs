﻿using System;
using System.Windows.Forms;

namespace UI
{
    public partial class NameInputDialog : Form
    {
        public string Input { get; private set; }

        public NameInputDialog()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(inputTextBox.Text.Trim()))
            {
                Input = inputTextBox.Text;
                this.Hide();
            }
            else
            {
                MessageBox.Show("Input cannot be empty.", "Empty input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        public void SetLabel(string label, string title)
        {
            dialogLabel.Text = label;
            this.Text = title;
        }

        public void SetButton(string buttonTextL, string buttonTextR)
        {
            buttonLeft.Text = buttonTextL;
            buttonRight.Text = buttonTextR;
        }

        public void SetInput(string input)
        {
            inputTextBox.Text = input;
        }

        private void NameInputDialog_Load(object sender, EventArgs e)
        {
            this.ActiveControl = inputTextBox;
        }
    }
}
